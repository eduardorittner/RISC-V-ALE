.globl _start
_start:
    li a0, 1
    li a7, 93
    ecall
